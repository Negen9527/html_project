/**
 * aes加密代码
 */


/**
 * aes加密方法
 * @param data  明文
 * @returns  密文
 */
function AESEncrypt(data){
	//密钥
	var key =  "fg5tred4qaedasds";
	
	var block = 16;
	var dataBase64 = Base64.encode(data).replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");

	var length = dataBase64.length % block;
	var pad = block - length;
	dataBase64 += new Array( pad + 1 ).join(  String.fromCharCode(pad) );

	key  = CryptoJS.enc.Hex.parse( CryptoJS.SHA256(key).toString() );
	var iv   = CryptoJS.enc.Latin1.parse('');

	return  CryptoJS.AES.encrypt(dataBase64, key,{iv:iv,mode:CryptoJS.mode.CBC,padding:CryptoJS.pad.ZeroPadding}).toString();
	
}
